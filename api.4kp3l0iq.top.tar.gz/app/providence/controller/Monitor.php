<?php
/**
 * 系统监控控制器（审计日志、登录日志、风险控制）
 */

namespace app\providence\controller;

use app\common\model\AuditLog as AuditLogModel;
use app\common\model\User;
use think\facade\Db;

class Monitor
{
    /**
     * 获取审计日志列表
     * GET /providence/audit-logs
     */
    public function auditLogs()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $module = input('get.module', '', 'trim');
        $action = input('get.action', '', 'trim');
        $startTime = input('get.start_time', '', 'trim');
        $endTime = input('get.end_time', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['admin_name', 'like', "%{$keyword}%"];
        }

        if (!empty($module)) {
            $where[] = ['module', '=', $module];
        }

        if (!empty($action)) {
            $where[] = ['action', '=', $action];
        }

        if (!empty($startTime)) {
            $where[] = ['created_at', '>=', $startTime];
        }
        if (!empty($endTime)) {
            $where[] = ['created_at', '<=', $endTime];
        }

        $list = AuditLogModel::where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        $total = AuditLogModel::where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取登录日志列表
     * GET /providence/login-logs
     */
    public function loginLogs()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $status = input('get.status', '', 'trim');
        $userType = input('get.user_type', '', 'trim');
        $startTime = input('get.start_time', '', 'trim');
        $endTime = input('get.end_time', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $userIds = User::where('username', 'like', "%{$keyword}%")->column('user_id');
            if (!empty($userIds)) {
                $where[] = ['user_id', 'in', $userIds];
            } else {
                return success('获取成功', ['list' => [], 'total' => 0]);
            }
        }

        if ($status !== '') {
            $where[] = ['status', '=', intval($status)];
        }

        if (!empty($userType)) {
            $where[] = ['user_type', '=', $userType];
        }

        if (!empty($startTime)) {
            $where[] = ['created_at', '>=', $startTime];
        }
        if (!empty($endTime)) {
            $where[] = ['created_at', '<=', $endTime];
        }

        $list = Db::name('login_log')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        // 关联用户信息
        foreach ($list as &$item) {
            if ($item['user_id']) {
                $user = User::find($item['user_id']);
                $item['username'] = $user ? $user->username : '';
            }
        }

        $total = Db::name('login_log')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取风险警报列表
     * GET /providence/risk/alerts
     */
    public function riskAlerts()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $level = input('get.level', '', 'trim');
        $type = input('get.type', '', 'trim');
        $status = input('get.status', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['message', 'like', "%{$keyword}%"];
        }

        if (!empty($level)) {
            $where[] = ['level', '=', $level];
        }

        if (!empty($type)) {
            $where[] = ['type', '=', $type];
        }

        if ($status !== '') {
            $where[] = ['status', '=', intval($status)];
        }

        $list = Db::name('risk_alert')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        // 关联用户信息
        foreach ($list as &$item) {
            if ($item['user_id']) {
                $user = User::find($item['user_id']);
                $item['username'] = $user ? $user->username : '';
            }
        }

        $total = Db::name('risk_alert')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取黑名单列表
     * GET /providence/risk/blacklist
     */
    public function riskBlacklist()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $type = input('get.type', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['value', 'like', "%{$keyword}%"];
        }

        if (!empty($type)) {
            $where[] = ['type', '=', $type];
        }

        $list = Db::name('risk_blacklist')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        $total = Db::name('risk_blacklist')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 添加黑名单
     * POST /providence/risk/blacklist
     */
    public function addBlacklist()
    {
        $type = input('post.type', '', 'trim');
        $value = input('post.value', '', 'trim');
        $reason = input('post.reason', '', 'trim');

        if (empty($type) || empty($value)) {
            return error('类型和值不能为空');
        }

        try {
            Db::name('risk_blacklist')->insert([
                'type' => $type,
                'value' => $value,
                'reason' => $reason,
                'created_at' => date('Y-m-d H:i:s')
            ]);

            return success('添加成功');
        } catch (\Exception $e) {
            return error('添加失败：' . $e->getMessage());
        }
    }

    /**
     * 获取风控规则
     * GET /providence/risk/rules
     */
    public function riskRules()
    {
        $rules = Db::name('risk_rule')
            ->order('id', 'asc')
            ->select();

        return success('获取成功', $rules);
    }

    /**
     * 更新风控规则
     * POST /providence/risk/rules
     */
    public function updateRiskRules()
    {
        $rules = input('post.');

        try {
            Db::name('risk_rule')
                ->where('key', 'risk_rules')
                ->updateOrInsert(
                    ['key' => 'risk_rules'],
                    ['value' => json_encode($rules), 'updated_at' => date('Y-m-d H:i:s')]
                );

            return success('更新成功');
        } catch (\Exception $e) {
            return error('更新失败：' . $e->getMessage());
        }
    }
}
