<?php
/**
 * 内容管理控制器（公告、弹窗、活动）
 */

namespace app\providence\controller;

use think\facade\Db;

class Content
{
    /**
     * 获取公告列表
     * GET /providence/announcements
     */
    public function announcements()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $status = input('get.status', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['title', 'like', "%{$keyword}%"];
        }

        if ($status !== '') {
            $where[] = ['status', '=', $status ? 1 : 0];
        }

        $list = Db::name('announcement')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        foreach ($list as &$item) {
            $item['is_important'] = (bool)($item['is_important'] ?? 0);
            $item['status'] = (bool)($item['status'] ?? 0);
        }

        $total = Db::name('announcement')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取弹窗列表
     * GET /providence/popups
     */
    public function popups()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $status = input('get.status', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['title', 'like', "%{$keyword}%"];
        }

        if ($status !== '') {
            $where[] = ['status', '=', $status ? 1 : 0];
        }

        $list = Db::name('popup')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        foreach ($list as &$item) {
            $item['status'] = (bool)($item['status'] ?? 0);
        }

        $total = Db::name('popup')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取活动列表
     * GET /providence/activities
     */
    public function activities()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $status = input('get.status', '', 'trim');
        $type = input('get.type', '', 'trim');

        $where = [];

        if (!empty($keyword)) {
            $where[] = ['title', 'like', "%{$keyword}%"];
        }

        if ($status !== '') {
            $where[] = ['status', '=', $status ? 1 : 0];
        }

        if (!empty($type)) {
            $where[] = ['type', '=', $type];
        }

        $list = Db::name('activity')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        foreach ($list as &$item) {
            $item['status'] = (bool)($item['status'] ?? 0);
            $item['show_popup'] = (bool)($item['show_popup'] ?? 0);
            $item['participants'] = (int)($item['participants'] ?? 0);
        }

        $total = Db::name('activity')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }
}
