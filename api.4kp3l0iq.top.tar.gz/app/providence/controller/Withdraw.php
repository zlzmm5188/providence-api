<?php
namespace app\providence\controller;

use app\common\model\User;
use app\common\model\WithdrawOrder;
use app\common\model\AuditLog;
use think\facade\Db;

class Withdraw
{
    public function index()
    {
        $status = input('status', '');
        $page = input('page', 1);
        $pageSize = input('pageSize', 20);
        
        $where = [];
        if ($status !== '') {
            $where[] = ['status', '=', $status];
        }
        
        $list = WithdrawOrder::where($where)
            ->page($page, $pageSize)
            ->order('id', 'desc')
            ->select();
        
        foreach ($list as &$item) {
            $user = User::find($item->user_id);
            $item->username = $user ? $user->username : '';
            $item->uid = $item->user_id;
        }
        
        $total = WithdrawOrder::where($where)->count();
        
        return success('获取成功', [
            'total' => $total,
            'list' => $list
        ]);
    }
    
    public function approve()
    {
        $id = input('id');
        $adminId = request()->userId;
        
        Db::startTrans();
        try {
            $withdraw = WithdrawOrder::where('id', $id)->lock(true)->find();
            
            if (!$withdraw || $withdraw->status != 0) {
                throw new \Exception('订单状态异常');
            }
            
            $user = User::where('user_id', $withdraw->user_id)->lock(true)->find();
            
            $frozenField = ($withdraw->currency === 'CNY') ? 'frozen_cny' : 'frozen_usdt';
            
            if (bcmath_comp($user->$frozenField, $withdraw->amount) === -1) {
                throw new \Exception('冻结金额不足');
            }
            
            $user->$frozenField = bcmath_sub($user->$frozenField, $withdraw->amount);
            $user->save();
            
            $withdraw->status = 1;
            $withdraw->reviewer_id = $adminId;
            $withdraw->reviewed_at = date('Y-m-d H:i:s');
            $withdraw->save();
            
            AuditLog::create([
                'admin_id' => $adminId,
                'action' => 'approve_withdraw',
                'module' => 'finance',
                'related_id' => $withdraw->id,
                'content' => json_encode(['order_no' => $withdraw->order_no, 'amount' => $withdraw->amount]),
                'ip' => request()->ip()
            ]);
            
            Db::commit();
            return success('审核通过');
            
        } catch (\Exception $e) {
            Db::rollback();
            return error($e->getMessage());
        }
    }
}
