<?php
/**
 * 日利宝管理控制器
 */

namespace app\providence\controller;

use app\common\model\User;
use think\facade\Db;

class Ribao
{
    /**
     * 获取日利宝记录列表
     * GET /providence/ribao/records
     */
    public function records()
    {
        $keyword = input('get.keyword', '', 'trim');
        $page = input('get.page', 1, 'intval');
        $pageSize = input('get.pageSize', 20, 'intval');
        $currency = input('get.currency', '', 'trim');
        $type = input('get.type', '', 'trim');
        $status = input('get.status', '', 'trim');
        $startTime = input('get.start_time', '', 'trim');
        $endTime = input('get.end_time', '', 'trim');

        $where = [];

        // 搜索关键词
        if (!empty($keyword)) {
            $userIds = User::where('username', 'like', "%{$keyword}%")->column('user_id');
            if (!empty($userIds)) {
                $where[] = ['user_id', 'in', $userIds];
            } else {
                return success('获取成功', ['list' => [], 'total' => 0]);
            }
        }

        // 币种筛选
        if (!empty($currency)) {
            $where[] = ['currency', '=', strtoupper($currency)];
        }

        // 类型筛选
        if (!empty($type)) {
            $where[] = ['type', '=', $type];
        }

        // 状态筛选
        if ($status !== '') {
            $where[] = ['status', '=', intval($status)];
        }

        // 时间筛选
        if (!empty($startTime)) {
            $where[] = ['created_at', '>=', $startTime];
        }
        if (!empty($endTime)) {
            $where[] = ['created_at', '<=', $endTime];
        }

        $list = Db::name('ribao')
            ->where($where)
            ->order('id', 'desc')
            ->page($page, $pageSize)
            ->select();

        // 关联用户信息
        foreach ($list as &$item) {
            $user = User::find($item['user_id']);
            $item['username'] = $user ? $user->username : '';
            $item['uid'] = (string)$item['user_id'];
        }

        $total = Db::name('ribao')->where($where)->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }

    /**
     * 获取日利宝配置
     * GET /providence/ribao/config
     */
    public function getConfig()
    {
        $config = Db::name('system_config')
            ->where('key', 'ribao_config')
            ->value('value');

        if ($config) {
            $config = json_decode($config, true);
        } else {
            $config = [
                'cny_rate' => 0.05,
                'usdt_rate' => 0.08,
                'min_amount' => 100,
                'max_amount' => 100000,
                'enabled' => true
            ];
        }

        return success('获取成功', $config);
    }

    /**
     * 更新日利宝配置
     * POST /providence/ribao/config
     */
    public function updateConfig()
    {
        $config = input('post.');

        try {
            Db::name('system_config')
                ->where('key', 'ribao_config')
                ->updateOrInsert(
                    ['key' => 'ribao_config'],
                    ['value' => json_encode($config), 'updated_at' => date('Y-m-d H:i:s')]
                );

            return success('更新成功');
        } catch (\Exception $e) {
            return error('更新失败：' . $e->getMessage());
        }
    }
}
