<?php
namespace app\api\controller;

use app\common\model\User;
use app\common\model\UserRelation;

class Team
{
    public function members()
    {
        $userId = request()->userId;
        $level = input('level', 0); // 0=全部, 1=一级, 2=二级
        $page = input('page', 1);
        $limit = input('limit', 10);
        
        $where = [['parent_id', '=', $userId]];
        
        if ($level > 0) {
            $where[] = ['level', '=', $level];
        }
        
        $relations = UserRelation::where($where)
            ->page($page, $limit)
            ->select();
        
        $userIds = array_column($relations->toArray(), 'child_id');
        
        $users = User::whereIn('user_id', $userIds)->select();
        
        $list = [];
        foreach ($relations as $relation) {
            foreach ($users as $user) {
                if ($user->user_id == $relation->child_id) {
                    $list[] = [
                        'user_id' => $user->user_id,
                        'username' => $user->username,
                        'vip_level' => $user->vip_level,
                        'total_invest' => $user->total_invest,
                        'level' => $relation->level,
                        'join_time' => $user->created_at
                    ];
                }
            }
        }
        
        $total = UserRelation::where($where)->count();
        
        return success('获取成功', [
            'total' => $total,
            'list' => $list
        ]);
    }
}
