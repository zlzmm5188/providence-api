<?php
namespace app\api\controller;

use app\common\model\User;
use app\common\model\InvestProject;
use app\common\model\InvestOrder;
use app\common\model\VipLevel;
use app\common\model\UserBankCard;
use app\common\model\UserUsdtAddress;
use app\common\model\WalletLog;
use app\common\service\VipService;
use app\common\service\ReferralService;
use app\common\service\TelegramBotService;
use think\facade\Db;

class Invest
{
    /**
     * 投资
     */
    public function create()
    {
        $userId = request()->userId;
        $projectId = input('project_id');
        $amount = input('amount');
        $currency = input('currency');
        $isTrial = input('is_trial', 0);

        Db::startTrans();
        try {
            // 1. 锁定用户
            $user = User::where('user_id', $userId)->lock(true)->find();

            // 2. 锁定项目
            $project = InvestProject::where('project_id', $projectId)
                ->where('status', 1)
                ->lock(true)
                ->find();

            if (!$project) {
                throw new \Exception('项目不存在或已下架');
            }

            // 3. 验证币种
            if ($project->currency !== $currency) {
                throw new \Exception('币种不匹配');
            }

            // 4. 验证金额范围
            if (bcmath_comp($amount, $project->min_amount) === -1 ||
                bcmath_comp($amount, $project->max_amount) === 1) {
                throw new \Exception('投资金额不在范围内');
            }

            // 5. 验证项目额度
            $remain = bcmath_sub($project->total_amount, $project->sold_amount);
            if (bcmath_comp($amount, $remain) === 1) {
                throw new \Exception('项目额度不足');
            }

            // 6. 验证VIP限制
            if ($project->vip_limit > 0 && $user->vip_level < $project->vip_limit) {
                throw new \Exception('VIP等级不足');
            }

            // 7. 验证前置条件（非体验金）
            if (!$isTrial) {
                if (!$user->is_kyc) {
                    throw new \Exception('请先完成实名认证');
                }

                // 检查收款方式
                if ($currency === 'CNY') {
                    $hasBank = UserBankCard::where('user_id', $userId)->count() > 0;
                    if (!$hasBank) {
                        throw new \Exception('请先绑定银行卡');
                    }
                } else {
                    $hasUsdt = UserUsdtAddress::where('user_id', $userId)->count() > 0;
                    if (!$hasUsdt) {
                        throw new \Exception('请先绑定USDT地址');
                    }
                }
            }

            // 8. 扣除余额
            $balanceField = $isTrial ? 'trial_balance' : ($currency === 'CNY' ? 'balance_cny' : 'balance_usdt');
            $oldBalance = $user->$balanceField;

            if (bcmath_comp($oldBalance, $amount) === -1) {
                throw new \Exception('余额不足');
            }

            $newBalance = bcmath_sub($oldBalance, $amount);
            $user->$balanceField = $newBalance;

            // 9. 累加total_invest（体验金不计入）
            if (!$isTrial) {
                $user->total_invest = bcmath_add($user->total_invest, $amount);
            }

            $user->save();

            // 10. 计算实际收益率
            $vipLevel = VipLevel::where('level', $user->vip_level)->find();
            $vipBonus = $vipLevel ? $vipLevel->interest_bonus : 0;
            $usdtBonus = ($currency === 'USDT') ? $project->usdt_bonus : 0;
            $finalRate = bcmath_add(bcmath_add($project->rate, $vipBonus, 6), $usdtBonus, 6);

            // 11. 计算收益
            $dailyProfit = bcmath_mul($amount, $finalRate);
            $totalProfit = bcmath_mul($dailyProfit, $project->cycle);

            // 12. 创建订单
            $orderNo = generate_order_no('I');
            $order = InvestOrder::create([
                'order_no' => $orderNo,
                'user_id' => $userId,
                'project_id' => $projectId,
                'project_name' => $project->name,
                'currency' => $currency,
                'amount' => $amount,
                'rate' => $finalRate,
                'cycle' => $project->cycle,
                'daily_profit' => $dailyProfit,
                'total_profit' => $totalProfit,
                'is_trial' => $isTrial,
                'status' => 1,
                'start_time' => date('Y-m-d H:i:s'),
                'end_time' => date('Y-m-d H:i:s', strtotime('+' . $project->cycle . ' days'))
            ]);

            // 13. 更新项目已售
            $project->sold_amount = bcmath_add($project->sold_amount, $amount);
            $project->save();

            // 14. 记录钱包流水
            WalletLog::create([
                'user_id' => $userId,
                'currency' => $currency,
                'type' => $isTrial ? 'trial_invest' : 'invest',
                'amount' => '-' . $amount,
                'balance_before' => $oldBalance,
                'balance_after' => $newBalance,
                'related_id' => $order->order_id,
                'remark' => "投资项目：{$project->name}"
            ]);

            // 15. 体验金标记已投资
            if ($isTrial) {
                \app\common\model\TrialFund::where('user_id', $userId)
                    ->where('status', 1)
                    ->update([
                        'status' => 2,
                        'invested_at' => date('Y-m-d H:i:s')
                    ]);
            }

            // 16. 检查VIP升级（非体验金）
            if (!$isTrial) {
                VipService::checkAndUpgrade($userId);
            }

            Db::commit();

            // 17. 发送Telegram通知
            TelegramBotService::notifyInvest([
                'username' => $user->username,
                'uid' => $user->uid
            ], [
                'amount' => $amount,
                'currency' => $currency,
                'ip' => request()->ip()
            ], [
                'name' => $project->name,
                'return_rate' => $project->return_rate,
                'duration' => $project->duration
            ]);

            // 18. 异步发放推荐返利（事务外，非体验金）
            if (!$isTrial) {
                try {
                    ReferralService::processReward($order->order_id, $userId, $amount, $currency);
                } catch (\Exception $e) {
                    // 返利失败不影响投资
                }
            }

            return success('投资成功', [
                'order_id' => $order->order_id,
                'amount' => $amount,
                'rate' => $finalRate,
                'daily_profit' => $dailyProfit,
                'total_profit' => $totalProfit,
                'end_time' => $order->end_time
            ]);

        } catch (\Exception $e) {
            Db::rollback();
            return error($e->getMessage());
        }
    }

    /**
     * 我的订单
     */
    public function orders()
    {
        $userId = request()->userId;
        $status = input('status', 0);
        $page = input('page', 1);
        $limit = input('limit', 10);

        $where = [['user_id', '=', $userId]];

        if ($status > 0) {
            $where[] = ['status', '=', $status];
        }

        $list = InvestOrder::where($where)
            ->page($page, $limit)
            ->order('order_id', 'desc')
            ->select();

        $total = InvestOrder::where($where)->count();

        return success('获取成功', [
            'total' => $total,
            'list' => $list
        ]);
    }
}
