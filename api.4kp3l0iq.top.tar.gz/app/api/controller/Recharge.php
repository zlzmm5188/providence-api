<?php
namespace app\api\controller;

use app\common\model\RechargeOrder;

class Recharge
{
    public function add()
    {
        $userId = request()->userId;
        $currency = input('currency');
        $amount = input('amount');
        $paymentMethod = input('payment_method', '');
        $paymentProof = input('payment_proof', '');
        
        if (bcmath_comp($amount, '0') <= 0) {
            return error('金额必须大于0');
        }
        
        $orderNo = generate_order_no('R');
        
        $order = RechargeOrder::create([
            'order_no' => $orderNo,
            'user_id' => $userId,
            'currency' => $currency,
            'amount' => $amount,
            'payment_method' => $paymentMethod,
            'payment_proof' => $paymentProof,
            'status' => 0
        ]);
        
        return success('充值申请已提交', [
            'order_id' => $order->id,
            'order_no' => $orderNo,
            'amount' => $amount,
            'status' => 0
        ]);
    }
    
    public function list()
    {
        $userId = request()->userId;
        $page = input('page', 1);
        $limit = input('limit', 10);
        
        $list = RechargeOrder::where('user_id', $userId)
            ->page($page, $limit)
            ->order('id', 'desc')
            ->select();
        
        $total = RechargeOrder::where('user_id', $userId)->count();
        
        return success('获取成功', [
            'total' => $total,
            'list' => $list
        ]);
    }
}
