<?php
/**
 * KYC实名认证控制器（含人脸识别）
 */

namespace app\api\controller;

use app\common\model\User;
use app\common\service\FileUploadService;
use app\common\service\TelegramBotService;
use think\facade\Db;

class Kyc
{
    /**
     * 提交实名认证（含人脸识别）
     * POST /api/user/kyc/submit
     */
    public function submit()
    {
        $userId = request()->userId;
        $realName = input('post.real_name', '', 'trim');
        $idCard = input('post.id_card', '', 'trim');
        $idCardFront = input('post.id_card_front', '', 'trim'); // 身份证正面base64
        $idCardBack = input('post.id_card_back', '', 'trim'); // 身份证反面base64
        $facePhoto = input('post.face_photo', '', 'trim'); // 人脸照片base64

        // 验证必填字段
        if (empty($realName) || empty($idCard) || empty($facePhoto)) {
            return error('请填写完整信息并上传人脸照片');
        }

        // 验证身份证号格式
        if (!preg_match('/^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/', $idCard)) {
            return error('身份证号格式不正确');
        }

        // 检查身份证是否已被使用
        $existingUser = User::where('id_card', $idCard)
            ->where('user_id', '<>', $userId)
            ->find();
        if ($existingUser) {
            return error('该身份证号已被其他账号使用');
        }

        $user = User::find($userId);
        if (!$user) {
            return error('用户不存在');
        }

        // 如果用户已实名认证，检查是否允许修改
        if ($user->is_kyc == 1 && !empty($user->id_card)) {
            if ($user->id_card !== $idCard) {
                return error('已实名认证的账号不能修改身份证号');
            }
        }

        Db::startTrans();
        try {
            // 使用安全的上传服务保存人脸照片
            $faceUploadResult = FileUploadService::saveBase64Image($facePhoto, 'face', 'uploads/face');
            if (!$faceUploadResult['success']) {
                return error($faceUploadResult['message']);
            }
            $facePhotoPath = $faceUploadResult['path'];

            // 保存身份证照片（可选）
            $idCardFrontPath = null;
            $idCardBackPath = null;
            if (!empty($idCardFront)) {
                $frontResult = FileUploadService::saveBase64Image($idCardFront, 'idcard_front', 'uploads/idcard');
                if ($frontResult['success']) {
                    $idCardFrontPath = $frontResult['path'];
                }
            }
            if (!empty($idCardBack)) {
                $backResult = FileUploadService::saveBase64Image($idCardBack, 'idcard_back', 'uploads/idcard');
                if ($backResult['success']) {
                    $idCardBackPath = $backResult['path'];
                }
            }

            // 更新用户信息（待审核状态）
            $user->real_name = $realName;
            $user->id_card = $idCard;
            $user->face_photo = $facePhotoPath;
            $user->is_kyc = 0; // 待人工审核
            $user->save();

            // 记录到人脸识别审核表（待审核）
            Db::name('face_verification')->insert([
                'user_id' => $userId,
                'type' => 'kyc',
                'face_image' => $facePhotoPath,
                'similarity' => 0,
                'liveness_score' => 0,
                'result' => 0, // 0-待审核
                'provider' => 'manual', // 人工审核
                'remark' => '实名认证待审核',
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s')
            ]);

            Db::commit();

            // 发送Telegram通知
            TelegramBotService::notifyKYC([
                'username' => $user->username,
                'uid' => $user->uid
            ], [
                'real_name' => $realName,
                'id_card' => $idCard,
                'ip' => request()->ip()
            ]);

            return success([
                'is_kyc' => 0,
                'message' => '实名认证已提交，等待人工审核',
                'face_photo_url' => $facePhotoPath
            ], '实名认证已提交，等待人工审核');

        } catch (\Exception $e) {
            Db::rollback();
            return error('提交失败：' . $e->getMessage());
        }
    }


    /**
     * 获取实名认证状态
     * GET /api/user/kyc/status
     */
    public function status()
    {
        $userId = request()->userId;
        $user = User::find($userId);

        if (!$user) {
            return error('用户不存在');
        }

        return success([
            'is_kyc' => $user->is_kyc ?? 0,
            'real_name' => $user->real_name ?? '',
            'id_card' => $user->id_card ? substr($user->id_card, 0, 6) . '****' . substr($user->id_card, -4) : '',
            'has_face_photo' => !empty($user->face_photo)
        ]);
    }
}
