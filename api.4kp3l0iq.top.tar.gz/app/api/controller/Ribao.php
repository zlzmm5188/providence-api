<?php
/**
 * 日利宝控制器（用户端）
 */

namespace app\api\controller;

use app\common\model\User;
use think\facade\Db;

class Ribao
{
    /**
     * 获取日利宝头部数据
     * GET /api/user/ribao/head
     */
    public function head()
    {
        $userId = request()->userId;

        $user = User::find($userId);
        if (!$user) {
            return error('用户不存在');
        }

        // 获取日利宝配置
        $config = Db::name('system_config')
            ->where('key', 'ribao_config')
            ->value('value');

        if ($config) {
            $config = json_decode($config, true);
        } else {
            $config = [
                'cny_rate' => 0.05,
                'usdt_rate' => 0.08,
                'min_amount' => 100,
                'max_amount' => 100000,
                'enabled' => true
            ];
        }

        // 计算昨日收益
        $yesterday = date('Y-m-d', strtotime('-1 day'));
        $yesterdayProfit = Db::name('wallet_log')
            ->where('user_id', $userId)
            ->where('type', 'ribao_profit')
            ->where('currency', 'CNY')
            ->where('created_at', 'like', $yesterday . '%')
            ->sum('amount');

        // 计算总收益
        $totalProfit = Db::name('wallet_log')
            ->where('user_id', $userId)
            ->where('type', 'ribao_profit')
            ->sum('amount');

        return success('获取成功', [
            'tmoney' => (float)$user->ribao_cny,  // 日利宝余额
            'tprofit' => (float)$totalProfit,     // 累计收益
            'yesterday_profit' => (float)$yesterdayProfit,  // 昨日收益
            'yesterdayProfit' => (float)$yesterdayProfit,   // 兼容字段
            'cny_rate' => (float)($config['cny_rate'] ?? 0.05),
            'usdt_rate' => (float)($config['usdt_rate'] ?? 0.08),
            'min_amount' => (float)($config['min_amount'] ?? 100),
            'max_amount' => (float)($config['max_amount'] ?? 100000),
            'enabled' => (bool)($config['enabled'] ?? true)
        ]);
    }

    /**
     * 获取日利宝信息
     * GET /api/user/ribao/info
     */
    public function info()
    {
        return $this->head();
    }

    /**
     * 转入日利宝
     * POST /api/user/ribao/transfer-in
     */
    public function transferIn()
    {
        $userId = request()->userId;
        $amount = input('post.amount/f', 0);
        $currency = input('post.currency', 'CNY', 'trim');

        if ($amount <= 0) {
            return error('转入金额必须大于0');
        }

        $user = User::find($userId);
        if (!$user) {
            return error('用户不存在');
        }

        // 检查余额
        $balanceField = $currency === 'USDT' ? 'balance_usdt' : 'balance_cny';
        $ribaoField = $currency === 'USDT' ? 'ribao_usdt' : 'ribao_cny';

        if (bccomp($user->$balanceField, $amount, 8) < 0) {
            return error('余额不足');
        }

        // 获取日利宝配置
        $config = Db::name('system_config')
            ->where('key', 'ribao_config')
            ->value('value');

        if ($config) {
            $config = json_decode($config, true);
        }

        $minAmount = (float)($config['min_amount'] ?? 100);
        $maxAmount = (float)($config['maxAmount'] ?? 100000);

        if ($amount < $minAmount) {
            return error("转入金额不能少于{$minAmount}元");
        }

        if ($amount > $maxAmount) {
            return error("转入金额不能超过{$maxAmount}元");
        }

        Db::startTrans();
        try {
            // 扣除余额
            $user->$balanceField = bcsub($user->$balanceField, $amount, 8);
            // 增加日利宝余额
            $user->$ribaoField = bcadd($user->$ribaoField, $amount, 8);
            $user->save();

            // 记录钱包日志
            Db::name('wallet_log')->insert([
                'user_id' => $userId,
                'type' => 'ribao_transfer_in',
                'amount' => -$amount,
                'currency' => strtoupper($currency),
                'remark' => '转入日利宝',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            Db::commit();

            return success('转入成功', [
                'balance' => (float)$user->$balanceField,
                'ribao_balance' => (float)$user->$ribaoField
            ]);
        } catch (\Exception $e) {
            Db::rollback();
            return error('转入失败：' . $e->getMessage());
        }
    }

    /**
     * 转出日利宝
     * POST /api/user/ribao/transfer-out
     */
    public function transferOut()
    {
        $userId = request()->userId;
        $amount = input('post.amount/f', 0);
        $currency = input('post.currency', 'CNY', 'trim');

        if ($amount <= 0) {
            return error('转出金额必须大于0');
        }

        $user = User::find($userId);
        if (!$user) {
            return error('用户不存在');
        }

        // 检查日利宝余额
        $ribaoField = $currency === 'USDT' ? 'ribao_usdt' : 'ribao_cny';
        $balanceField = $currency === 'USDT' ? 'balance_usdt' : 'balance_cny';

        if (bccomp($user->$ribaoField, $amount, 8) < 0) {
            return error('日利宝余额不足');
        }

        Db::startTrans();
        try {
            // 扣除日利宝余额
            $user->$ribaoField = bcsub($user->$ribaoField, $amount, 8);
            // 增加余额
            $user->$balanceField = bcadd($user->$balanceField, $amount, 8);
            $user->save();

            // 记录钱包日志
            Db::name('wallet_log')->insert([
                'user_id' => $userId,
                'type' => 'ribao_transfer_out',
                'amount' => $amount,
                'currency' => strtoupper($currency),
                'remark' => '转出日利宝',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            Db::commit();

            return success('转出成功', [
                'balance' => (float)$user->$balanceField,
                'ribao_balance' => (float)$user->$ribaoField
            ]);
        } catch (\Exception $e) {
            Db::rollback();
            return error('转出失败：' . $e->getMessage());
        }
    }

    /**
     * 获取日利宝记录
     * GET /api/user/ribao/records
     */
    public function records()
    {
        $userId = request()->userId;
        $page = input('get.page', 1, 'intval');
        $limit = input('get.limit', 20, 'intval');

        $list = Db::name('wallet_log')
            ->where('user_id', $userId)
            ->whereIn('type', ['ribao_transfer_in', 'ribao_transfer_out', 'ribao_profit'])
            ->order('id', 'desc')
            ->page($page, $limit)
            ->select();

        $total = Db::name('wallet_log')
            ->where('user_id', $userId)
            ->whereIn('type', ['ribao_transfer_in', 'ribao_transfer_out', 'ribao_profit'])
            ->count();

        return success('获取成功', [
            'list' => $list,
            'total' => $total
        ]);
    }
}
