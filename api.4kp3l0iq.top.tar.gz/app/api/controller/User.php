<?php
namespace app\api\controller;

use app\common\model\User as UserModel;
use app\common\model\UserRelation;

// 确保加载辅助函数
require_once dirname(__DIR__, 2) . '/common/helpers.php';

class User
{
    /**
     * 获取用户信息
     */
    public function index()
    {
        // 手动解析Token（绕过中间件问题）
        $userId = get_user_id(); // 使用helper函数

        if (!$userId) {
            return error('请先登录', [], 401);
        }

        $user = UserModel::find($userId);

        if (!$user) {
            return error('用户不存在');
        }

        // 统计团队人数
        $teamCount1 = UserRelation::where('parent_id', $userId)
            ->where('level', 1)
            ->count();

        $teamCount2 = UserRelation::where('parent_id', $userId)
            ->where('level', 2)
            ->count();

        return success([
            'id' => $user->id,
            'uid' => $user->uid,
            'username' => $user->username,
            'realname' => $user->realname,
            'vip_level' => $user->vip_level,
            'total_invest' => $user->total_invest,
            'balance_cny' => $user->balance_cny,
            'balance_usdt' => $user->balance_usdt,
            'frozen_cny' => $user->frozen_cny,
            'frozen_usdt' => $user->frozen_usdt,
            'ribao_cny' => $user->ribao_cny ?? '0.00000000',
            'ribao_usdt' => $user->ribao_usdt ?? '0.00000000',
            'points' => $user->points,
            'realname_status' => $user->realname_status,
            'invite_code' => $user->invite_code,
            'team_count' => $teamCount1 + $teamCount2,
            'team_count_1' => $teamCount1,
            'team_count_2' => $teamCount2
        ], '获取成功');
    }

    /**
     * 获取VIP进度
     */
    public function vipProgress()
    {
        $userId = request()->userId;

        $user = UserModel::find($userId);

        // 获取当前VIP配置
        $currentVip = \app\common\model\VipLevel::where('level', $user->vip_level)->find();

        // 获取下一级VIP配置
        $nextVip = \app\common\model\VipLevel::where('level', $user->vip_level + 1)->find();

        $data = [
            'current_level' => $user->vip_level,
            'current_name' => $currentVip ? $currentVip->name : 'VIP0',
            'total_invest' => $user->total_invest,
            'current_required' => $currentVip ? $currentVip->required_invest : '0.00000000'
        ];

        if ($nextVip) {
            $needInvest = bcmath_sub($nextVip->required_invest, $user->total_invest);
            $progress = 0;

            if (bcmath_comp($user->total_invest, $currentVip->required_invest) >= 0) {
                $total = bcmath_sub($nextVip->required_invest, $currentVip->required_invest);
                $current = bcmath_sub($user->total_invest, $currentVip->required_invest);
                if (bcmath_comp($total, '0') > 0) {
                    $progress = bcmath_mul(bcmath_div($current, $total), '100');
                }
            }

            $data['next_level'] = $nextVip->level;
            $data['next_name'] = $nextVip->name;
            $data['next_required'] = $nextVip->required_invest;
            $data['need_invest'] = $needInvest;
            $data['progress'] = round((float)$progress, 2);
        } else {
            $data['next_level'] = null;
            $data['next_name'] = '已达最高等级';
            $data['next_required'] = null;
            $data['need_invest'] = '0.00000000';
            $data['progress'] = 100;
        }

        return success('获取成功', $data);
    }
}
