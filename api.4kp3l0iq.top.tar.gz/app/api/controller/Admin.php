<?php
namespace app\api\controller;

use app\common\model\Project;
use think\facade\Request;

class Admin
{
    /**
     * 发布项目（管理员专用）
     */
    public function publishProject()
    {
        // 验证管理员权限
        $adminToken = Request::header('Admin-Token');
        if ($adminToken !== env('admin.api_token', 'providence_admin_2025')) {
            return error('无权限');
        }
        
        // 获取参数
        $data = Request::post();
        
        // 验证必填字段
        $required = ['name', 'rate', 'cycle', 'min_amount', 'max_amount'];
        foreach ($required as $field) {
            if (!isset($data[$field]) || $data[$field] === '') {
                return error("缺少必填字段: {$field}");
            }
        }
        
        // 创建项目
        try {
            $project = Project::create([
                'name' => $data['name'],
                'rate' => $data['rate'],
                'cycle' => $data['cycle'],
                'min_amount' => $data['min_amount'],
                'max_amount' => $data['max_amount'],
                'description' => $data['description'] ?? '',
                'status' => 1,
                'sort' => $data['sort'] ?? 100,
                'create_time' => time(),
                'update_time' => time()
            ]);
            
            return success([
                'id' => $project->id,
                'name' => $project->name
            ], '项目发布成功');
            
        } catch (\Exception $e) {
            return error('发布失败: ' . $e->getMessage());
        }
    }
    
    /**
     * 获取项目列表（管理员）
     */
    public function getProjects()
    {
        $adminToken = Request::header('Admin-Token');
        if ($adminToken !== env('admin.api_token', 'providence_admin_2025')) {
            return error('无权限');
        }
        
        $list = Project::order('sort desc, id desc')->select()->toArray();
        
        return success([
            'list' => $list,
            'total' => count($list)
        ]);
    }
}
