<?php
namespace app\api\controller;

use app\common\service\SevenPayService;
use app\common\service\UsdtService;
use think\facade\Request;

/**
 * 支付控制器V2（SevenPay + USDT）
 */
class PaymentV2 extends Base
{
    /**
     * 微信支付（SevenPay）
     */
    public function wechat()
    {
        $amount = Request::param('amount');
        
        if ($amount < 100) {
            return json(['code' => -1, 'msg' => '充值金额不能小于100元']);
        }
        
        $result = SevenPayService::createPayment($this->userId, $amount, 'wechat');
        
        return json($result);
    }
    
    /**
     * 支付宝支付（SevenPay）
     */
    public function alipay()
    {
        $amount = Request::param('amount');
        
        if ($amount < 100) {
            return json(['code' => -1, 'msg' => '充值金额不能小于100元']);
        }
        
        $result = SevenPayService::createPayment($this->userId, $amount, 'alipay');
        
        return json($result);
    }
    
    /**
     * USDT充值配置
     */
    public function usdtConfig()
    {
        $config = UsdtService::getUsdtConfig();
        
        return json([
            'code' => 1,
            'msg' => '获取成功',
            'data' => $config
        ]);
    }
    
    /**
     * 创建USDT充值订单
     */
    public function usdtCreate()
    {
        $amount = Request::param('amount');
        
        if (!$amount || $amount <= 0) {
            return json(['code' => -1, 'msg' => '请输入充值金额']);
        }
        
        $result = UsdtService::createUsdtOrder($this->userId, $amount);
        
        return json($result);
    }
    
    /**
     * 查询USDT订单状态
     */
    public function usdtCheck()
    {
        $orderNo = Request::param('order_no');
        
        if (!$orderNo) {
            return json(['code' => -1, 'msg' => '缺少订单号']);
        }
        
        $result = UsdtService::checkOrder($orderNo);
        
        return json($result);
    }
    
    /**
     * SevenPay支付回调
     */
    public function sevenPayNotify()
    {
        $postData = Request::post();
        
        $result = SevenPayService::handleNotify($postData);
        
        echo $result;
    }
}
