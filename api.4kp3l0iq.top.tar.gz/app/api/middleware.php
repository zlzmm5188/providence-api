<?php
// api应用中间件定义文件
return [
    // 全局中间件
    \app\common\middleware\CorsMiddleware::class,
];
