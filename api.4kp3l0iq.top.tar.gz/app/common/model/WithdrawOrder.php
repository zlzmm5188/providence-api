<?php
namespace app\common\model;
use think\Model;

class WithdrawOrder extends Model
{
    protected $table = 'withdraw_orders';
}
