<?php
namespace app\common\model;
use think\Model;

class InvestProject extends Model
{
    protected $table = 'projects';
    protected $pk = 'id';
}
