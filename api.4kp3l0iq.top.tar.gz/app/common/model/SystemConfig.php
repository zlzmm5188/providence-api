<?php
namespace app\common\model;
use think\Model;

class SystemConfig extends Model
{
    protected $table = 'system_configs';
}
