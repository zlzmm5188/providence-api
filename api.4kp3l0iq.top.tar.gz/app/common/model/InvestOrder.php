<?php
namespace app\common\model;
use think\Model;

class InvestOrder extends Model
{
    protected $table = 'invest_orders';
    protected $pk = 'order_id';
}
