<?php
namespace app\common\model;
use think\Model;

class RechargeOrder extends Model
{
    protected $table = 'recharge_orders';
}
