<?php
namespace app\common\model;

use think\Model;

class User extends Model
{
    protected $pk = 'id'; // 修复：主键是id，不是user_id
    protected $table = 'users';

    // 隐藏字段
    protected $hidden = ['password', 'pay_password'];

    // 类型转换
    protected $type = [
        'user_id' => 'integer',
        'vip_level' => 'integer',
        'is_kyc' => 'integer',
        'status' => 'integer',
        'points' => 'integer',
        'is_internal' => 'integer',
    ];

    // 自动完成
    protected $auto = [];
    protected $insert = ['invite_code'];

    // 生成邀请码
    protected function setInviteCodeAttr($value, $data)
    {
        return generate_invite_code();
    }

    // 获取推荐人
    public function parent()
    {
        return $this->hasOne(User::class, 'user_id', 'parent_id');
    }

    // 获取一级下级
    public function children()
    {
        return $this->hasMany(User::class, 'parent_id', 'user_id');
    }
}
