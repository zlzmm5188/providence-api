<?php
/**
 * Providence 系统辅助函数（最简化版本）
 */

if (!function_exists('bcmath_add')) {
    /**
     * 精确加法（8位小数）
     */
    function bcmath_add($a, $b, $scale = 8) {
        return bcadd((string)$a, (string)$b, $scale);
    }
}

if (!function_exists('bcmath_sub')) {
    /**
     * 精确减法（8位小数）
     */
    function bcmath_sub($a, $b, $scale = 8) {
        return bcsub((string)$a, (string)$b, $scale);
    }
}

if (!function_exists('bcmath_mul')) {
    /**
     * 精确乘法（8位小数）
     */
    function bcmath_mul($a, $b, $scale = 8) {
        return bcmul((string)$a, (string)$b, $scale);
    }
}

if (!function_exists('bcmath_div')) {
    /**
     * 精确除法（8位小数）
     */
    function bcmath_div($a, $b, $scale = 8) {
        if (bccomp((string)$b, '0', $scale) === 0) {
            throw new \Exception('除数不能为0');
        }
        return bcdiv((string)$a, (string)$b, $scale);
    }
}

if (!function_exists('bcmath_comp')) {
    /**
     * 精确比较
     * @return int -1:小于, 0:等于, 1:大于
     */
    function bcmath_comp($a, $b, $scale = 8) {
        return bccomp((string)$a, (string)$b, $scale);
    }
}

if (!function_exists('success')) {
    /**
     * 成功响应
     */
    function success($msg = '操作成功', $data = []) {
        return json([
            'code' => 1,
            'msg' => $msg,
            'data' => $data
        ]);
    }
}

if (!function_exists('error')) {
    /**
     * 失败响应
     */
    function error($msg = '操作失败', $code = -1, $data = []) {
        return json([
            'code' => $code,
            'msg' => $msg,
            'data' => $data
        ]);
    }
}

if (!function_exists('generate_order_no')) {
    /**
     * 生成订单号
     * @param string $prefix R=充值, W=提现, I=投资
     */
    function generate_order_no($prefix = 'O') {
        $timestamp = date('YmdHis') . substr(microtime(), 2, 6);
        $random = str_pad(mt_rand(0, 999999), 6, '0', STR_PAD_LEFT);
        return $prefix . $timestamp . $random;
    }
}

if (!function_exists('generate_invite_code')) {
    /**
     * 生成8位随机邀请码
     */
    function generate_invite_code() {
        return str_pad(mt_rand(10000000, 99999999), 8, '0', STR_PAD_LEFT);
    }
}

if (!function_exists('generate_unique_uid')) {
    /**
     * 生成唯一UID（8位数字）
     */
    function generate_unique_uid() {
        do {
            $uid = str_pad(mt_rand(10000000, 99999999), 8, '0', STR_PAD_LEFT);
            $exists = \app\common\model\User::where('uid', $uid)->count();
        } while ($exists > 0);
        return $uid;
    }
}

if (!function_exists('generate_unique_invite_code')) {
    /**
     * 生成唯一邀请码（8位数字）
     */
    function generate_unique_invite_code() {
        do {
            $code = str_pad(mt_rand(10000000, 99999999), 8, '0', STR_PAD_LEFT);
            $exists = \app\common\model\User::where('invite_code', $code)->count();
        } while ($exists > 0);
        return $code;
    }
}

if (!function_exists('check_username')) {
    /**
     * 验证用户名（4-20位字母数字下划线）
     */
    function check_username($username) {
        return preg_match('/^[a-zA-Z0-9_]{4,20}$/', $username);
    }
}

if (!function_exists('check_id_card')) {
    /**
     * 验证身份证号
     */
    function check_id_card($idCard) {
        return preg_match('/^[1-9]\d{5}(18|19|20)\d{2}(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])\d{3}[\dXx]$/', $idCard);
    }
}
