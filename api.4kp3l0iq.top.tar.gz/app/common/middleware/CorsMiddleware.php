<?php
namespace app\common\middleware;

/**
 * CORS跨域中间件
 * 用于开发环境允许前端跨域访问
 */
class CorsMiddleware
{
    public function handle($request, \Closure $next)
    {
        $origin = $request->header('origin', '*');

        // OPTIONS预检请求立即返回
        if ($request->method() === 'OPTIONS') {
            return response('', 200, [
                'Access-Control-Allow-Origin' => $origin,
                'Access-Control-Allow-Methods' => 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
                'Access-Control-Allow-Headers' => 'Authorization, Content-Type, Token, token, X-Requested-With, Accept, Origin, X-Token',
                'Access-Control-Allow-Credentials' => 'true',
                'Access-Control-Max-Age' => '86400',
            ]);
        }

        // 处理实际请求
        $response = $next($request);

        // 设置CORS响应头
        $response->header([
            'Access-Control-Allow-Origin' => $origin,
            'Access-Control-Allow-Methods' => 'GET, POST, PUT, DELETE, OPTIONS, PATCH',
            'Access-Control-Allow-Headers' => 'Authorization, Content-Type, Token, token, X-Requested-With, Accept, Origin, X-Token',
            'Access-Control-Allow-Credentials' => 'true',
            'Access-Control-Expose-Headers' => 'Authorization, Token, token',
        ]);

        return $response;
    }
}
