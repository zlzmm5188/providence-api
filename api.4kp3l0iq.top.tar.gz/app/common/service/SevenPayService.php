<?php
namespace app\common\service;

use think\facade\Db;
use think\facade\Log;

/**
 * SevenPay支付服务
 * 文档: https://sevenpay.lh.plus/merchants/#/api-document
 */
class SevenPayService
{
    // 商户配置
    private static $config = [
        'merchantId' => 'M1763172182',
        'username' => 'XY8888',
        'merchantName' => 'XY',
        'apiKey' => '3e4cbfb35a35787ccc98bd13027b4a02',
        'payGateway' => 'https://sevenpay.lh.plus/index.php/pay/create',
        'queryGateway' => 'https://sevenpay.lh.plus/index.php/pay/query',
        'callbackIP' => '23.94.207.16',
        'channels' => [
            'wechat' => ['code' => 'S02', 'name' => '微信扫码', 'min' => 100, 'max' => 3000],
            'alipay' => ['code' => 'S01', 'name' => '支付宝小额原生', 'min' => 100, 'max' => 20000]
        ]
    ];

    /**
     * 创建支付订单
     */
    public static function createPayment($userId, $amount, $channel = 'wechat')
    {
        // 验证通道
        if (!isset(self::$config['channels'][$channel])) {
            return ['code' => -1, 'msg' => '无效的支付通道'];
        }

        $channelConfig = self::$config['channels'][$channel];

        // 验证金额范围
        if ($amount < $channelConfig['min'] || $amount > $channelConfig['max']) {
            return [
                'code' => -1,
                'msg' => "充值金额限制：{$channelConfig['min']}-{$channelConfig['max']}元"
            ];
        }

        // 生成订单号
        $orderNo = 'R' . strtoupper(substr($channel, 0, 2)) . date('YmdHis') . rand(1000, 9999);

        // 创建充值记录
        $rechargeId = Db::name('recharge_records')->insertGetId([
            'user_id' => $userId,
            'order_no' => $orderNo,
            'amount' => $amount,
            'currency' => 'CNY',
            'payment_method' => $channel,
            'status' => 0,
            'created_at' => date('Y-m-d H:i:s')
        ]);

        // 构建请求参数
        $params = [
            'merchantCode' => self::$config['merchantId'],
            'channelType' => $channelConfig['code'],
            'merchantOrderNo' => $orderNo,
            'amount' => number_format($amount, 2, '.', ''),
            'notifyUrl' => request()->domain() . '/api/payment/sevenpay-notify',
            'returnUrl' => request()->domain() . '/recharge-success.html',
            'ip' => request()->ip(),
            'title' => 'Providence充值',
            'describe' => '用户充值'
        ];

        // 生成签名
        $params['sign'] = self::generateSign($params);

        // 发送请求
        $response = self::httpPost(self::$config['payGateway'], $params);

        Log::info('SevenPay创建订单', [
            'user_id' => $userId,
            'order_no' => $orderNo,
            'amount' => $amount,
            'channel' => $channel,
            'response' => $response
        ]);

        if ($response && isset($response['code']) && $response['code'] == 1) {
            return [
                'code' => 1,
                'msg' => '创建成功',
                'data' => [
                    'order_no' => $orderNo,
                    'recharge_id' => $rechargeId,
                    'pay_url' => $response['data']['payUrl'] ?? '',
                    'qrcode' => $response['data']['qrCode'] ?? '',
                    'amount' => $amount,
                    'channel' => $channelConfig['name']
                ]
            ];
        }

        return [
            'code' => -1,
            'msg' => $response['msg'] ?? '创建订单失败'
        ];
    }

    /**
     * 支付回调处理
     */
    public static function handleNotify($postData)
    {
        Log::info('SevenPay支付回调', $postData);

        // 验证IP
        $clientIP = request()->ip();
        if ($clientIP !== self::$config['callbackIP']) {
            Log::warning('SevenPay回调IP不匹配', ['client_ip' => $clientIP]);
        }

        // 验证签名
        if (!self::verifySign($postData)) {
            Log::error('SevenPay回调签名验证失败', $postData);
            return 'SIGN_ERROR';
        }

        $orderNo = $postData['merchantOrderNo'];
        $amount = $postData['amount'];
        $status = $postData['status'] ?? 0; // 1=成功

        if ($status != 1) {
            return 'STATUS_ERROR';
        }

        // 查询订单
        $recharge = Db::name('recharge_records')->where('order_no', $orderNo)->find();

        if (!$recharge) {
            Log::error('订单不存在', ['order_no' => $orderNo]);
            return 'ORDER_NOT_FOUND';
        }

        if ($recharge['status'] == 1) {
            return 'SUCCESS'; // 已处理
        }

        // 处理充值
        Db::startTrans();
        try {
            // 更新订单状态
            Db::name('recharge_records')->where('order_no', $orderNo)->update([
                'status' => 1,
                'transaction_id' => $postData['orderNo'] ?? '',
                'paid_at' => date('Y-m-d H:i:s')
            ]);

            // 更新用户余额
            Db::name('users')->where('id', $recharge['user_id'])->inc('balance_cny', $amount)->update();
            Db::name('users')->where('id', $recharge['user_id'])->inc('total_recharge_cny', $amount)->update();

            // 记录钱包日志
            $balanceAfter = Db::name('users')->where('id', $recharge['user_id'])->value('balance_cny');
            Db::name('wallet_logs')->insert([
                'user_id' => $recharge['user_id'],
                'type' => 'recharge',
                'currency' => 'CNY',
                'amount' => $amount,
                'balance_after' => $balanceAfter,
                'remark' => '充值到账',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            Db::commit();

            Log::info('充值成功', [
                'user_id' => $recharge['user_id'],
                'order_no' => $orderNo,
                'amount' => $amount
            ]);

            // 发送Telegram通知
            $user = Db::name('users')->where('id', $recharge['user_id'])->find();
            TelegramBotService::notifyRecharge([
                'username' => $user['username'],
                'uid' => $user['uid']
            ], [
                'amount' => $amount,
                'currency' => 'CNY',
                'payment_method' => $recharge['payment_method'],
                'order_no' => $orderNo,
                'status' => 1,
                'ip' => $recharge['user_ip'] ?? ''
            ]);

            return 'SUCCESS';
        } catch (\Exception $e) {
            Db::rollback();
            Log::error('充值处理失败: ' . $e->getMessage());
            return 'ERROR';
        }
    }

    /**
     * 生成签名
     */
    private static function generateSign($params)
    {
        // 1. 排除sign字段
        unset($params['sign']);

        // 2. 按key排序
        ksort($params);

        // 3. 拼接成字符串
        $signStr = '';
        foreach ($params as $key => $val) {
            if ($val !== '' && $val !== null) {
                $signStr .= $key . '=' . $val . '&';
            }
        }

        // 4. 加上密钥
        $signStr .= 'key=' . self::$config['apiKey'];

        // 5. MD5加密（小写）
        return strtolower(md5($signStr));
    }

    /**
     * 验证签名
     */
    private static function verifySign($data)
    {
        $sign = $data['sign'] ?? '';
        $calculatedSign = self::generateSign($data);

        return $sign === $calculatedSign;
    }

    /**
     * HTTP POST请求
     */
    private static function httpPost($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode == 200) {
            return json_decode($result, true);
        }

        return null;
    }
}
