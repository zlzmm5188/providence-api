<?php
namespace app\common\service;

use think\facade\Db;
use think\facade\Log;
use think\facade\Cache;

/**
 * USDT充值服务（简化版）
 * 后台配置收款地址，用户转账后手动上传凭证或系统监控到账
 */
class UsdtService
{
    /**
     * 获取USDT充值配置
     */
    public static function getUsdtConfig()
    {
        // 从配置表或.env读取USDT收款地址
        $address = env('USDT_ADDRESS', '');

        if (!$address) {
            // 如果没有配置，从数据库读取
            $config = Db::name('system_config')
                ->where('key', 'usdt_address')
                ->value('value');

            $address = $config ?: 'TYourUsdtAddressHere';
        }

        return [
            'address' => $address,
            'network' => 'TRC20',
            'min_amount' => 10,
            'max_amount' => 50000,
            'rate' => 7.2, // USDT汇率（CNY）
            'tips' => [
                '请使用TRC20网络转账USDT',
                '最小充值金额：10 USDT',
                '到账时间：12个区块确认后（约3-5分钟）',
                '转账完成后请耐心等待，系统会自动检测'
            ]
        ];
    }

    /**
     * 创建USDT充值订单
     */
    public static function createUsdtOrder($userId, $amount)
    {
        $config = self::getUsdtConfig();

        // 验证金额
        if ($amount < $config['min_amount'] || $amount > $config['max_amount']) {
            return [
                'code' => -1,
                'msg' => "充值金额限制：{$config['min_amount']}-{$config['max_amount']} USDT"
            ];
        }

        // 生成订单号
        $orderNo = 'RUSDT' . date('YmdHis') . rand(1000, 9999);

        // 创建充值记录
        $rechargeId = Db::name('recharge_records')->insertGetId([
            'user_id' => $userId,
            'order_no' => $orderNo,
            'amount' => $amount,
            'currency' => 'USDT',
            'payment_method' => 'usdt',
            'status' => 0, // 待支付
            'created_at' => date('Y-m-d H:i:s')
        ]);

        Log::info('USDT订单创建', [
            'user_id' => $userId,
            'order_no' => $orderNo,
            'amount' => $amount
        ]);

        return [
            'code' => 1,
            'msg' => '订单创建成功',
            'data' => [
                'order_no' => $orderNo,
                'recharge_id' => $rechargeId,
                'address' => $config['address'],
                'network' => $config['network'],
                'amount' => $amount,
                'rate' => $config['rate'],
                'cny_amount' => $amount * $config['rate'],
                'tips' => $config['tips']
            ]
        ];
    }

    /**
     * 查询USDT订单状态
     */
    public static function checkOrder($orderNo)
    {
        $recharge = Db::name('recharge_records')
            ->where('order_no', $orderNo)
            ->find();

        if (!$recharge) {
            return ['code' => -1, 'msg' => '订单不存在'];
        }

        return [
            'code' => 1,
            'data' => [
                'order_no' => $recharge['order_no'],
                'amount' => $recharge['amount'],
                'status' => $recharge['status'], // 0=待支付 1=已支付
                'created_at' => $recharge['created_at'],
                'paid_at' => $recharge['paid_at'] ?? null
            ]
        ];
    }

    /**
     * 监控USDT到账（通过TronGrid API）
     * 定时任务调用：php think usdt:monitor
     */
    public static function monitorTransactions()
    {
        $config = self::getUsdtConfig();
        $address = $config['address'];

        if (!$address || $address === 'TYourUsdtAddressHere') {
            Log::warning('USDT地址未配置');
            return false;
        }

        // 获取最近的交易记录
        $transactions = self::fetchTronTransactions($address);

        if (!$transactions) {
            return false;
        }

        $processedCount = 0;

        foreach ($transactions as $tx) {
            // 只处理转入交易
            if ($tx['to'] !== $address) {
                continue;
            }

            // 检查是否已处理
            $exists = Db::name('recharge_records')
                ->where('transaction_hash', $tx['hash'])
                ->find();

            if ($exists) {
                continue;
            }

            // 匹配订单（根据金额和时间）
            $recharge = Db::name('recharge_records')
                ->where('currency', 'USDT')
                ->where('status', 0)
                ->where('amount', $tx['amount'])
                ->where('created_at', '>=', date('Y-m-d H:i:s', strtotime('-1 hour')))
                ->order('id desc')
                ->find();

            if ($recharge) {
                // 处理到账
                self::processArrival($recharge['id'], $tx);
                $processedCount++;
            }
        }

        Log::info('USDT监控完成', ['processed' => $processedCount]);

        return true;
    }

    /**
     * 处理USDT到账
     */
    private static function processArrival($rechargeId, $transaction)
    {
        Db::startTrans();
        try {
            $recharge = Db::name('recharge_records')->where('id', $rechargeId)->find();

            if ($recharge['status'] == 1) {
                Db::rollback();
                return false; // 已处理
            }

            // 更新订单状态
            Db::name('recharge_records')->where('id', $rechargeId)->update([
                'status' => 1,
                'transaction_hash' => $transaction['hash'],
                'paid_at' => date('Y-m-d H:i:s')
            ]);

            // 更新用户余额
            $amount = $recharge['amount'];
            Db::name('users')->where('id', $recharge['user_id'])->inc('balance_usdt', $amount)->update();
            Db::name('users')->where('id', $recharge['user_id'])->inc('total_recharge_usdt', $amount)->update();

            // 记录钱包日志
            $balanceAfter = Db::name('users')->where('id', $recharge['user_id'])->value('balance_usdt');
            Db::name('wallet_logs')->insert([
                'user_id' => $recharge['user_id'],
                'type' => 'recharge',
                'currency' => 'USDT',
                'amount' => $amount,
                'balance_after' => $balanceAfter,
                'remark' => 'USDT充值到账',
                'created_at' => date('Y-m-d H:i:s')
            ]);

            Db::commit();

            Log::info('USDT到账处理成功', [
                'recharge_id' => $rechargeId,
                'user_id' => $recharge['user_id'],
                'amount' => $amount,
                'hash' => $transaction['hash']
            ]);

            // 发送Telegram通知
            $user = Db::name('users')->where('id', $recharge['user_id'])->find();
            TelegramBotService::notifyRecharge([
                'username' => $user['username'],
                'uid' => $user['uid']
            ], [
                'amount' => $amount,
                'currency' => 'USDT',
                'payment_method' => 'usdt',
                'order_no' => $recharge['order_no'],
                'status' => 1,
                'ip' => $recharge['user_ip'] ?? ''
            ]);

            return true;
        } catch (\Exception $e) {
            Db::rollback();
            Log::error('USDT到账处理失败: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * 查询Tron区块链交易（使用TronGrid API）
     */
    private static function fetchTronTransactions($address)
    {
        $apiKey = env('TRON_API_KEY', '');
        $cacheKey = 'usdt_tx_' . $address;

        // 缓存5分钟，避免频繁请求
        $cached = Cache::get($cacheKey);
        if ($cached) {
            return $cached;
        }

        $url = "https://api.trongrid.io/v1/accounts/{$address}/transactions/trc20?limit=20&only_confirmed=true";

        $headers = [];
        if ($apiKey) {
            $headers[] = "TRON-PRO-API-KEY: {$apiKey}";
        }

        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode !== 200) {
            Log::error('TronGrid API请求失败', ['code' => $httpCode]);
            return [];
        }

        $data = json_decode($response, true);

        if (!isset($data['data']) || !is_array($data['data'])) {
            return [];
        }

        $transactions = [];

        foreach ($data['data'] as $tx) {
            // 只处理USDT交易（合约地址：TR7NHqjeKQxGTCi8q8ZY4pL8otSzgjLj6t）
            if (!isset($tx['token_info']['symbol']) || $tx['token_info']['symbol'] !== 'USDT') {
                continue;
            }

            $transactions[] = [
                'hash' => $tx['transaction_id'],
                'from' => $tx['from'],
                'to' => $tx['to'],
                'amount' => $tx['value'] / 1000000, // USDT精度6位
                'timestamp' => $tx['block_timestamp']
            ];
        }

        // 缓存结果
        Cache::set($cacheKey, $transactions, 300); // 5分钟

        return $transactions;
    }
}
