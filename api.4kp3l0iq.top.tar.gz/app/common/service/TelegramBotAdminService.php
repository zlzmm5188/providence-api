<?php
namespace app\common\service;

use think\facade\Db;
use think\facade\Log;

/**
 * Telegram Bot 管理员命令服务
 */
class TelegramBotAdminService
{
    private static $botToken = '';
    private static $adminIds = [6159132946, 7289705725]; // 管理员ID

    /**
     * 初始化配置
     */
    private static function init()
    {
        self::$botToken = env('TELEGRAM_BOT_TOKEN', '');

        // 从.env文件读取（备用方案）
        if (!self::$botToken) {
            $envFile = app()->getRootPath() . '.env';
            if (file_exists($envFile)) {
                $lines = file($envFile, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
                foreach ($lines as $line) {
                    if (strpos($line, 'TELEGRAM_BOT_TOKEN=') === 0) {
                        self::$botToken = trim(substr($line, strlen('TELEGRAM_BOT_TOKEN=')));
                        break;
                    }
                }
            }
        }
    }

    /**
     * 处理Webhook消息
     */
    public static function handleWebhook($update)
    {
        self::init();

        // 处理普通消息
        if (isset($update['message'])) {
            $message = $update['message'];
            $chatId = $message['chat']['id'];
            $userId = $message['from']['id'];
            $text = $message['text'] ?? '';

            // 检查是否是管理员
            if (!in_array($userId, self::$adminIds)) {
                // 非管理员不响应
                return false;
            }

            // 处理命令
            if ($text == '/start' || $text == '/menu' || $text == '菜单') {
                return self::sendMainMenu($chatId);
            }

            return true;
        }

        // 处理按钮回调
        if (isset($update['callback_query'])) {
            $callbackQuery = $update['callback_query'];
            $chatId = $callbackQuery['message']['chat']['id'];
            $userId = $callbackQuery['from']['id'];
            $data = $callbackQuery['data'];
            $messageId = $callbackQuery['message']['message_id'];

            // 检查是否是管理员
            if (!in_array($userId, self::$adminIds)) {
                return false;
            }

            // 应答回调查询
            self::answerCallbackQuery($callbackQuery['id']);

            // 处理不同的按钮回调
            switch ($data) {
                case 'stats_today':
                    return self::sendTodayStats($chatId, $messageId);
                case 'stats_total':
                    return self::sendTotalStats($chatId, $messageId);
                case 'projects_expiring':
                    return self::sendExpiringProjects($chatId, $messageId);
                case 'project_add':
                    return self::sendProjectAddForm($chatId, $messageId);
                case 'project_list':
                    return self::sendProjectList($chatId, $messageId);
                case 'back_menu':
                    return self::sendMainMenu($chatId, $messageId);
                default:
                    // 处理项目下架
                    if (strpos($data, 'project_offline_') === 0) {
                        $projectId = str_replace('project_offline_', '', $data);
                        return self::offlineProject($chatId, $messageId, $projectId);
                    }
                    break;
            }
        }

        return false;
    }

    /**
     * 发送主菜单
     */
    private static function sendMainMenu($chatId, $messageId = null)
    {
        $message = "🤖 <b>Providence 管理面板</b>\n\n";
        $message .= "请选择功能：";

        $buttons = [
            [
                ['text' => '📊 今日数据', 'callback_data' => 'stats_today'],
                ['text' => '📈 总体数据', 'callback_data' => 'stats_total']
            ],
            [
                ['text' => '⏰ 明日到期项目', 'callback_data' => 'projects_expiring']
            ],
            [
                ['text' => '➕ 发布项目', 'callback_data' => 'project_add'],
                ['text' => '📋 项目列表', 'callback_data' => 'project_list']
            ]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送今日统计数据
     */
    private static function sendTodayStats($chatId, $messageId)
    {
        $today = date('Y-m-d');
        $todayStart = $today . ' 00:00:00';
        $todayEnd = $today . ' 23:59:59';

        // 今日注册
        $newUsers = Db::name('users')
            ->where('created_at', 'between', [$todayStart, $todayEnd])
            ->count();

        // 今日实名
        $newKyc = Db::name('users')
            ->where('is_kyc', 1)
            ->where('updated_at', 'between', [$todayStart, $todayEnd])
            ->count();

        // 今日充值
        $todayRecharge = Db::name('recharge_records')
            ->where('status', 1)
            ->where('created_at', 'between', [$todayStart, $todayEnd])
            ->select();

        $rechargeCny = 0;
        $rechargeUsdt = 0;
        foreach ($todayRecharge as $r) {
            if ($r['currency'] == 'CNY') {
                $rechargeCny += $r['amount'];
            } else {
                $rechargeUsdt += $r['amount'];
            }
        }

        // 今日提现
        $todayWithdraw = Db::name('withdraw_orders')
            ->where('created_at', 'between', [$todayStart, $todayEnd])
            ->select();

        $withdrawCny = 0;
        $withdrawUsdt = 0;
        $withdrawPending = 0;
        foreach ($todayWithdraw as $w) {
            if ($w['status'] == 0) {
                $withdrawPending++;
            }
            if ($w['currency'] == 'CNY') {
                $withdrawCny += $w['amount'];
            } else {
                $withdrawUsdt += $w['amount'];
            }
        }

        $message = "📊 <b>今日数据统计</b>\n\n";
        $message .= "📅 日期: " . $today . "\n\n";
        $message .= "👥 新注册: <b>{$newUsers}</b> 人\n";
        $message .= "🪪 新实名: <b>{$newKyc}</b> 人\n\n";
        $message .= "💰 充值总额:\n";
        $message .= "  ├─ CNY: <b>" . number_format($rechargeCny, 2) . "</b>\n";
        $message .= "  └─ USDT: <b>" . number_format($rechargeUsdt, 2) . "</b>\n\n";
        $message .= "🏧 提现总额:\n";
        $message .= "  ├─ CNY: <b>" . number_format($withdrawCny, 2) . "</b>\n";
        $message .= "  ├─ USDT: <b>" . number_format($withdrawUsdt, 2) . "</b>\n";
        $message .= "  └─ ⚠️ 待审核: <b>{$withdrawPending}</b> 笔\n";

        $buttons = [
            [['text' => '🔙 返回主菜单', 'callback_data' => 'back_menu']]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送总体统计数据
     */
    private static function sendTotalStats($chatId, $messageId)
    {
        // 总注册
        $totalUsers = Db::name('users')->count();

        // 总实名
        $totalKyc = Db::name('users')->where('is_kyc', 1)->count();

        // 总充值
        $totalRecharge = Db::name('recharge_records')
            ->where('status', 1)
            ->select();

        $rechargeCny = 0;
        $rechargeUsdt = 0;
        foreach ($totalRecharge as $r) {
            if ($r['currency'] == 'CNY') {
                $rechargeCny += $r['amount'];
            } else {
                $rechargeUsdt += $r['amount'];
            }
        }

        // 总提现
        $totalWithdraw = Db::name('withdraw_orders')->select();

        $withdrawCny = 0;
        $withdrawUsdt = 0;
        foreach ($totalWithdraw as $w) {
            if ($w['currency'] == 'CNY') {
                $withdrawCny += $w['amount'];
            } else {
                $withdrawUsdt += $w['amount'];
            }
        }

        $message = "📈 <b>总体数据统计</b>\n\n";
        $message .= "👥 总用户: <b>{$totalUsers}</b> 人\n";
        $message .= "🪪 总实名: <b>{$totalKyc}</b> 人\n\n";
        $message .= "💰 累计充值:\n";
        $message .= "  ├─ CNY: <b>" . number_format($rechargeCny, 2) . "</b>\n";
        $message .= "  └─ USDT: <b>" . number_format($rechargeUsdt, 2) . "</b>\n\n";
        $message .= "🏧 累计提现:\n";
        $message .= "  ├─ CNY: <b>" . number_format($withdrawCny, 2) . "</b>\n";
        $message .= "  └─ USDT: <b>" . number_format($withdrawUsdt, 2) . "</b>\n";

        $buttons = [
            [['text' => '🔙 返回主菜单', 'callback_data' => 'back_menu']]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送明日到期项目
     */
    private static function sendExpiringProjects($chatId, $messageId)
    {
        $tomorrow = date('Y-m-d', strtotime('+1 day'));
        $tomorrowStart = $tomorrow . ' 00:00:00';
        $tomorrowEnd = $tomorrow . ' 23:59:59';

        $expiringOrders = Db::name('invest_orders')
            ->alias('io')
            ->join('users u', 'io.user_id = u.user_id')
            ->join('projects p', 'io.project_id = p.id')
            ->where('io.status', 1)
            ->where('io.end_time', 'between', [$tomorrowStart, $tomorrowEnd])
            ->field('io.*, u.username, u.uid, p.name as project_name')
            ->select();

        $count = count($expiringOrders);
        $totalAmount = 0;
        foreach ($expiringOrders as $order) {
            $totalAmount += $order['amount'];
        }

        $message = "⏰ <b>明日到期项目</b>\n\n";
        $message .= "📅 到期日期: {$tomorrow}\n";
        $message .= "📊 到期订单: <b>{$count}</b> 笔\n";
        $message .= "💰 到期金额: <b>" . number_format($totalAmount, 2) . "</b> CNY\n\n";

        if ($count > 0) {
            $message .= "详细列表:\n";
            $message .= "━━━━━━━━━━━━━━━━━━━━\n";

            $limit = min($count, 10); // 最多显示10条
            for ($i = 0; $i < $limit; $i++) {
                $order = $expiringOrders[$i];
                $message .= "\n" . ($i + 1) . ". <b>{$order['project_name']}</b>\n";
                $message .= "   用户: {$order['username']} ({$order['uid']})\n";
                $message .= "   金额: {$order['amount']} {$order['currency']}\n";
            }

            if ($count > 10) {
                $message .= "\n... 还有 " . ($count - 10) . " 笔订单\n";
            }
        }

        $buttons = [
            [['text' => '🔙 返回主菜单', 'callback_data' => 'back_menu']]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送项目列表
     */
    private static function sendProjectList($chatId, $messageId)
    {
        $projects = Db::name('projects')
            ->where('status', 1)
            ->order('id', 'desc')
            ->select();

        $message = "📋 <b>当前项目列表</b>\n\n";

        if (count($projects) == 0) {
            $message .= "暂无项目\n";
        } else {
            foreach ($projects as $project) {
                $message .= "🎯 <b>{$project['name']}</b>\n";
                $message .= "   收益率: {$project['return_rate']}%\n";
                $message .= "   周期: {$project['duration']}天\n";
                $message .= "   最低: {$project['min_amount']} | 最高: {$project['max_amount']}\n";
                $message .= "\n";
            }
        }

        // 生成按钮
        $buttons = [];
        foreach ($projects as $project) {
            $buttons[] = [
                ['text' => "❌ 下架 [{$project['name']}]", 'callback_data' => 'project_offline_' . $project['id']]
            ];
        }
        $buttons[] = [['text' => '🔙 返回主菜单', 'callback_data' => 'back_menu']];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 下架项目
     */
    private static function offlineProject($chatId, $messageId, $projectId)
    {
        $project = Db::name('projects')->where('id', $projectId)->find();

        if (!$project) {
            $message = "❌ 项目不存在";
        } else {
            Db::name('projects')->where('id', $projectId)->update(['status' => 0]);
            $message = "✅ 项目已下架\n\n";
            $message .= "项目名称: <b>{$project['name']}</b>\n";
            $message .= "收益率: {$project['return_rate']}%\n";
        }

        $buttons = [
            [
                ['text' => '📋 项目列表', 'callback_data' => 'project_list'],
                ['text' => '🔙 主菜单', 'callback_data' => 'back_menu']
            ]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送项目添加表单说明
     */
    private static function sendProjectAddForm($chatId, $messageId)
    {
        $message = "➕ <b>发布新项目</b>\n\n";
        $message .= "⚠️ 请使用后台管理面板发布项目\n\n";
        $message .= "或发送以下格式的消息：\n";
        $message .= "<code>/addproject\n";
        $message .= "项目名称\n";
        $message .= "收益率(%) 周期(天)\n";
        $message .= "最低金额 最高金额</code>\n\n";
        $message .= "示例:\n";
        $message .= "<code>/addproject\n";
        $message .= "稳健理财A\n";
        $message .= "2.6 30\n";
        $message .= "1000 50000</code>";

        $buttons = [
            [['text' => '🔙 返回主菜单', 'callback_data' => 'back_menu']]
        ];

        return self::sendOrEditMessage($chatId, $message, $buttons, $messageId);
    }

    /**
     * 发送或编辑消息
     */
    private static function sendOrEditMessage($chatId, $message, $buttons, $messageId = null)
    {
        $data = [
            'chat_id' => $chatId,
            'text' => $message,
            'parse_mode' => 'HTML',
            'reply_markup' => [
                'inline_keyboard' => $buttons
            ]
        ];

        if ($messageId) {
            // 编辑现有消息
            $data['message_id'] = $messageId;
            $url = "https://api.telegram.org/bot" . self::$botToken . "/editMessageText";
        } else {
            // 发送新消息
            $url = "https://api.telegram.org/bot" . self::$botToken . "/sendMessage";
        }

        return self::httpPost($url, $data);
    }

    /**
     * 应答回调查询
     */
    private static function answerCallbackQuery($callbackQueryId)
    {
        $url = "https://api.telegram.org/bot" . self::$botToken . "/answerCallbackQuery";
        $data = ['callback_query_id' => $callbackQueryId];
        return self::httpPost($url, $data);
    }

    /**
     * HTTP POST请求
     */
    private static function httpPost($url, $data)
    {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_TIMEOUT, 10);

        $result = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($httpCode == 200 && $result) {
            return json_decode($result, true);
        }

        return null;
    }
}
