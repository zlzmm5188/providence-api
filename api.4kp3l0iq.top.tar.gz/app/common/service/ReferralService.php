<?php
namespace app\common\service;

use app\common\model\User;
use app\common\model\VipLevel;
use app\common\model\ReferralReward;
use app\common\model\WalletLog;

class ReferralService
{
    /**
     * 发放推荐返利
     */
    public static function processReward($orderId, $userId, $amount, $currency)
    {
        $user = User::find($userId);
        
        // 一级返利
        if ($user->parent_id) {
            $parent = User::where('user_id', $user->parent_id)->lock(true)->find();
            $vipLevel = VipLevel::where('level', $parent->vip_level)->find();
            
            $rate1 = $vipLevel->referral_rate_1;
            $reward1 = bcmath_mul($amount, $rate1);
            
            // 发放到余额
            $field = ($currency === 'CNY') ? 'balance_cny' : 'balance_usdt';
            $parent->$field = bcmath_add($parent->$field, $reward1);
            $parent->save();
            
            // 记录返利
            ReferralReward::create([
                'user_id' => $parent->user_id,
                'from_user_id' => $userId,
                'order_id' => $orderId,
                'level' => 1,
                'currency' => $currency,
                'order_amount' => $amount,
                'rate' => $rate1,
                'reward_amount' => $reward1
            ]);
            
            // 记录流水
            WalletLog::create([
                'user_id' => $parent->user_id,
                'currency' => $currency,
                'type' => 'referral',
                'amount' => $reward1,
                'balance_before' => bcmath_sub($parent->$field, $reward1),
                'balance_after' => $parent->$field,
                'related_id' => $orderId,
                'remark' => "推荐返利：一级下级投资"
            ]);
            
            // 二级返利
            if ($parent->parent_id) {
                $grandParent = User::where('user_id', $parent->parent_id)->lock(true)->find();
                $rate2 = $vipLevel->referral_rate_2;
                
                if (bcmath_comp($rate2, '0') > 0) {
                    $reward2 = bcmath_mul($amount, $rate2);
                    
                    $grandParent->$field = bcmath_add($grandParent->$field, $reward2);
                    $grandParent->save();
                    
                    ReferralReward::create([
                        'user_id' => $grandParent->user_id,
                        'from_user_id' => $userId,
                        'order_id' => $orderId,
                        'level' => 2,
                        'currency' => $currency,
                        'order_amount' => $amount,
                        'rate' => $rate2,
                        'reward_amount' => $reward2
                    ]);
                    
                    WalletLog::create([
                        'user_id' => $grandParent->user_id,
                        'currency' => $currency,
                        'type' => 'referral',
                        'amount' => $reward2,
                        'balance_before' => bcmath_sub($grandParent->$field, $reward2),
                        'balance_after' => $grandParent->$field,
                        'related_id' => $orderId,
                        'remark' => "推荐返利：二级下级投资"
                    ]);
                }
            }
        }
        
        return true;
    }
}
