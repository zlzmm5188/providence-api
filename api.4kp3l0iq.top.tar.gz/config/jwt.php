<?php
return [
    'secret' => env('jwt.secret', 'providence_jwt_2025_4kp3l0iq_top_secure_key'),
    'ttl' => 7200, // 2小时
    'alg' => 'HS256',
];
