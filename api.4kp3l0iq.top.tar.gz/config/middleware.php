<?php
// 全局中间件定义文件
return [
    // CORS跨域中间件（必须放在最前面）
    \app\common\middleware\CorsMiddleware::class,
];
