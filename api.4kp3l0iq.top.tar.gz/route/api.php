<?php
use think\facade\Route;

// ========== 无需登录的接口 ==========
Route::group('api', function () {

    // 认证
    Route::post('auth/register', 'app\api\controller\Auth@register');
    Route::post('auth/login', 'app\api\controller\Auth@login');

    // 项目列表（公开）
    Route::get('project/index', 'app\api\controller\Project@index');
    Route::get('project/detail', 'app\api\controller\Project@detail');

    // 找回密码
    Route::post('auth/forgot-password/step1', 'app\api\controller\ForgotPassword@step1');
    Route::post('auth/forgot-password/step2', 'app\api\controller\ForgotPassword@step2');
    Route::post('auth/forgot-password/step3', 'app\api\controller\ForgotPassword@step3');
    Route::post('auth/forgot-password/check-status', 'app\api\controller\ForgotPassword@checkStatus');

    // 支付回调（无需认证）
    Route::post('payment-v2/sevenpay-notify', 'app\api\controller\PaymentV2@sevenPayNotify');

    // Telegram Bot Webhook（无需认证）
    Route::post('telegram/webhook', 'app\api\controller\TelegramWebhook@index');

});


// ========== 需要登录的接口 ==========
Route::group('api', function () {

    // 认证
    Route::post('auth/logout', 'app\api\controller\Auth@logout');

    // 用户
    Route::get('user/index', 'app\api\controller\User@index');
    Route::get('user/vip-progress', 'app\api\controller\User@vipProgress');

    // 日利宝
    Route::get('user/ribao/head', 'app\api\controller\Ribao@head');
    Route::get('user/ribao/info', 'app\api\controller\Ribao@info');
    Route::get('user/ribao/records', 'app\api\controller\Ribao@records');
    Route::post('user/ribao/transfer-in', 'app\api\controller\Ribao@transferIn');
    Route::post('user/ribao/transfer-out', 'app\api\controller\Ribao@transferOut');

    // 投资
    Route::post('invest/create', 'app\api\controller\Invest@create');
    Route::get('invest/orders', 'app\api\controller\Invest@orders');

    // 充值
    Route::post('recharge/add', 'app\api\controller\Recharge@add');
    Route::get('recharge/list', 'app\api\controller\Recharge@list');

    // 提现
    Route::post('withdraw/create', 'app\api\controller\Withdraw@create');
    Route::get('withdraw/list', 'app\api\controller\Withdraw@list');

    // 团队
    Route::get('team/members', 'app\api\controller\Team@members');
    Route::get('team/reward-info', 'app\api\controller\Team@rewardInfo');
    Route::post('team/claim-reward', 'app\api\controller\Team@claimReward');

    // 积分
    Route::get('points/balance', 'app\api\controller\Points@balance');
    Route::get('points/logs', 'app\api\controller\Points@logs');
    Route::post('points/exchange', 'app\api\controller\Points@exchange');

    // 支付V2
    Route::post('payment-v2/wechat', 'app\api\controller\PaymentV2@wechat');
    Route::post('payment-v2/alipay', 'app\api\controller\PaymentV2@alipay');
    Route::get('payment-v2/usdt-config', 'app\api\controller\PaymentV2@usdtConfig');
    Route::post('payment-v2/usdt-create', 'app\api\controller\PaymentV2@usdtCreate');
    Route::get('payment-v2/usdt-check', 'app\api\controller\PaymentV2@usdtCheck');

    // 币种兑换
    Route::get('currency/get-usdt-rate', 'app\api\controller\Currency@getUsdtRate');
    Route::post('currency/exchange-cny-to-usdt', 'app\api\controller\Currency@exchangeCnyToUsdt');

    // AI客服
    Route::post('ai/chat', 'app\api\controller\AIChat@chat');

    // KYC实名认证
    Route::post('user/kyc/submit', 'app\api\controller\Kyc@submit');
    Route::get('user/kyc/status', 'app\api\controller\Kyc@status');

    // 人脸识别
    Route::post('user/face-upload', 'app\api\controller\Face@upload');
    Route::post('user/face-verify', 'app\api\controller\Face@verify');
    Route::get('user/face/status', 'app\api\controller\Face@status');

})->middleware(\app\common\middleware\AuthMiddleware::class);

// 管理员API（Bot专用）
Route::post("bot/admin/project/publish", "app\\api\\controller\\BotAdmin@publishProject");
Route::get("bot/admin/finance/stats", "app\\api\\controller\\BotAdmin@getFinanceStats");
