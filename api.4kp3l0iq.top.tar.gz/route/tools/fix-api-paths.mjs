import fs from "fs";
import path from "path";

const targetDir = "/www/wwwroot/4kp3l0iq.top";
const correct = "https://api.4kp3l0iq.top/api";

function fixFile(file) {
    let content = fs.readFileSync(file, "utf8");
    let changed = false;

    const patterns = [
        [/https:\/\/api\.4kp3l0iq\.top\/api\/api/g, "双重/api"],
        [/https:\/\/apis\.frevix\.top/g, "旧域名apis.frevix.top"],
        [/https:\/\/api\.4kp3l0iq\.top\/index\.php\/api/g, "index.php路径"],
        [/http:\/\/localhost:8888\/api/g, "localhost"],
        [/http:\/\/localhost:8888/g, "localhost无/api"]
    ];

    patterns.forEach(([pattern, desc]) => {
        if (pattern.test(content)) {
            content = content.replace(pattern, correct);
            changed = true;
            console.log(`  ✔ 修复 ${desc}: ${file}`);
        }
    });

    if (changed) {
        fs.writeFileSync(file, content);
    }
}

function walk(dir) {
    try {
        fs.readdirSync(dir).forEach(name => {
            if (name.startsWith('.')) return;
            
            const file = path.join(dir, name);
            const stat = fs.lstatSync(file);
            
            if (stat.isDirectory()) {
                walk(file);
            } else if (file.endsWith(".js") || file.endsWith(".html")) {
                fixFile(file);
            }
        });
    } catch (err) {
        console.log(`  ⚠ 跳过目录: ${dir}`);
    }
}

console.log("🔧 开始扫描并修复前端API路径...");
console.log(`📂 目标目录: ${targetDir}\n`);
walk(targetDir);
console.log("\n✅ 完成！");

