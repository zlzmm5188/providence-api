#!/bin/bash
cd /www/wwwroot/api.4kp3l0iq.top
/usr/bin/php think usdt:monitor >> /www/wwwlogs/usdt_monitor.log 2>&1
